package matriz;


public class almacen {
    private bebidas [][] estanterias;
    private int cont=0;
    public almacen(int un, int dos) {
        estanterias = new bebidas [un][dos];
        
    }
    
    void agregarBebida(bebidas b){
        boolean p=false;    

        for (int i = 0; i < estanterias.length && !p  ; i++) {
            for (int j = 0; j < estanterias[0].length && !p; j++) {
                if(estanterias[i][j]==null){
                    estanterias[i][j]=b;
                    p=true;
                }
                
            }
               
        }
        
        if(p){
            System.out.println("agregado");
        }else{
            System.out.println("no agregado");
        }

    }
       void eliminarBebida(int id){
        boolean p=false;    
        for (int i = 0; i < estanterias.length && !p ; i++) {
            for (int j = 0; j < estanterias[0].length && !p; j++) {
                if(estanterias[i][j]!=null){
                    if(estanterias[i][j].getId()==id){
                        estanterias[i][j]=null;
                       p=true;
                    }
                }
            }
        }
        
        if(p){
            System.out.println("borrado");
        }else{
            System.out.println("no existe");
        }

    }
       
       void mostrar(){

        for (int i = 0; i < estanterias.length ; i++) {
            for (int j = 0; j < estanterias[0].length; j++) {
                if(estanterias[i][j]!=null){
                    System.out.println(estanterias[i][j]);
                }
            }
        }
        }
       
      public void costoTodasLasBebidas(){
         double contadorbeb=0;
         for (int i = 0; i < estanterias.length ; i++) {
            for (int j = 0; j < estanterias[0].length; j++) {
                
                if(estanterias[i][j] != null){
                    contadorbeb= contadorbeb + estanterias[i][j].getPrecio();
                }
               
                
            }
        }
           
           System.out.println("Precio total de bebidas:"+contadorbeb);
           
       }
         public void costoMarcas(String marca){
         double contadormarca=0;
         for (int i = 0; i < estanterias.length ; i++) {
            for (int j = 0; j < estanterias[0].length; j++) {
                if(estanterias[i][j] != null){
                    if(estanterias[i][j].getMarca().equals(marca)){
                    contadormarca= contadormarca + estanterias[i][j].getPrecio();
                }
                }
                
               
                
            }
        }
           
           System.out.println("bebidas marca:"+contadormarca);
           
       }
    
       public void precioEstanteria(int columna){
         double contadorest=0;
         for (int i = 0; i < estanterias.length ; i++) {
 
                 if(estanterias[i][columna] != null){
                    
                    contadorest= contadorest + estanterias[i][columna].getPrecio();
                }        
            }
           System.out.println("bebidas estanteria:"+columna+" precio: "+contadorest);
           
       }  
    
    

}
