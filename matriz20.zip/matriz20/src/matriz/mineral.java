package matriz;

public class mineral extends bebidas {

    private String origen;
    
    public mineral(float litro, double precio, String marca) {
        super(litro, precio, marca);
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    
    
    
    
}
