package matriz;

public class almaprueba {

    public static void main(String[] args) {
        
        almacen a = new almacen(2,2);
        azucaradas azuc1 = new azucaradas(25,false,2,25, "manaos");
        azucaradas azuc2 = new azucaradas(15,true,1,10, "cunnington");
        mineral mine1 = new mineral(2,50,"ives");
        azucaradas azuc3 = new azucaradas(25,false,2,25, "manaos");
        
        a.agregarBebida(azuc1);
        a.agregarBebida(azuc2);
        a.agregarBebida(mine1);
        a.agregarBebida(azuc3);
        
        
        a.costoTodasLasBebidas();
        a.costoMarcas("manaos");
        a.mostrar();
        a.precioEstanteria(0);
        a.precioEstanteria(1);
        
    }
    
}
