package matriz;


public class azucaradas extends bebidas{
    private float azucar;
    private boolean prom;
    
    public azucaradas(float azucar, boolean prom, float litro, double precio, String marca) {
        super(litro, precio, marca);
        this.azucar=azucar;
        this.prom=prom;
    }

    public float getAzucar() {
        return azucar;
    }

    public void setAzucar(float azucar) {
        this.azucar = azucar;
    }

    public boolean isProm() {
        return prom;
    }

    @Override
    public double getPrecio() {
        if(isProm()){
            return super.getPrecio()*0.9;
        }else{
        return super.getPrecio();
        }
        
        
        
    }
    
    

    public void setProm(boolean prom) {
        this.prom = prom;
    }
    
}
