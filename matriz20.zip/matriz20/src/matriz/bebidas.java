package matriz;

public class bebidas {
    private static int idActual=1;
    
    private int id;
    private float litro;
    private double precio;
    private String marca;

    public bebidas( float litro, double precio, String marca) {
        this.id=idActual++;
        this.litro = litro;
        this.precio = precio;
        this.marca = marca;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getLitro() {
        return litro;
    }

    public void setLitro(float litro) {
        this.litro = litro;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public String toString() {
        return "bebidas{" + "id=" + id + ", litro=" + litro + ", precio=" + precio + ", marca=" + marca + '}';
    }

    
    
    
    
    
}
